
There are three solutions in this directory for lab6:

- lab6runA.f initial testing of the VC with vc_test.sv. Steps 7-9 in Lab book.

- lab6runB.f DUT test with a single VC using switch_test.sv. Steps 10-12 in
  Lab book.

- lab6runC.f DUT test with all 4 VCs using modified switch_test.sv
  (fullswitch_test.sv). Steps 13 to 16 in Lab book.

